import java.util.Scanner;
import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Random rand = new Random();
        menu();
        int level = sc.nextInt();
        int levelpilihan [] [] = null;
        switch(level){
            case 1:
                levelpilihan = new int [4][4];
                System.out.println("======================");
                int baris = rand.nextInt(4);
                int kolom = rand.nextInt(4);
                levelpilihan [baris] [kolom] =2;

                for (int i =0; i < 4 ; i++){
                    for (int j =0; j <4 ; j++){
                        if (levelpilihan[i][j] == 0){

                            System.out.print(" [ "+ " ]");}
                        else System.out.print(" [ "+ levelpilihan[i][j] + " ]");
                    }
                    System.out.println();
                }

                System.out.println("======================");

            break;
            case 2:
                levelpilihan = new int [5][5];
                System.out.println("============================");
                 baris = rand.nextInt(5);
                 kolom = rand.nextInt(5);
                levelpilihan [baris] [kolom] =2;
                for (int i =0; i < 5 ; i++){
                    for (int j =0; j < 5 ; j++){
                        if (levelpilihan[i][j] == 0){
                        System.out.print(" [ "+ " ]");}
                        else System.out.print(" [ "+ levelpilihan[i][j] + " ]");
                    }
                    System.out.println();
                }

                System.out.println("============================");
            break;
            case 0:
                System.out.println("Finish");
             break;
            default:
                System.out.println("Tidak ada level lain lagi");
            break;
        }// level
    }
    public static void menu(){
        System.out.println(" Selamat datang di 2048");
        System.out.println("=====================");
        System.out.println("        4 x 4");
        System.out.println("        5 x 5");
        System.out.println("=====================");
        System.out.println(" Ada level 1 dan 2");
        System.out.println(" Mau level berapa: ");


    }
}

